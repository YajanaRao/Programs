import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText
from email.MIMEBase import MIMEBase
from email import encoders
import os
import logging
import sys
import Allmethods
import Allvariables

currentpath = os.path.dirname(os.path.realpath(__file__))

try:	
	#calling method and storing all the required data from text file
	fromaddr = Allmethods.ReadTextFile2(Allvariables.inputfilename,"FromEmail")
	password = Allmethods.ReadTextFile2(Allvariables.inputfilename,"Password")
	toaddrs = Allmethods.ReadTextFile2(Allvariables.inputfilename,"ToEmail")
	toaddrs = toaddrs.split(',')
	attachmentfileName = Allmethods.ReadTextFile2(Allvariables.inputfilename,"ReportZipFileName")
	attachmentfileName = attachmentfileName+'.zip'
	if Allvariables.applicationName != "Mammoth":
		zipfolderpath = Allmethods.ReadTextFile2(Allvariables.scriptinputfile,"CSVFileFolderName")
	else:
		zipfolderpath = Allmethods.ReadTextFile2(Allvariables.scriptinputfile,"CombinedExcelFolderName")
	attachmentFilePath = currentpath+''+zipfolderpath+'/'+attachmentfileName
	filePermission = 'rb'
	emailsubject = Allmethods.ReadTextFile2(Allvariables.inputfilename,"EmailSubject")
	emailbody = Allmethods.ReadTextFile2(Allvariables.inputfilename,"EmailBody")
except Exception as e:
	print "Exception is: "+str(e)
	sys.exit(0)

#this method sends email to the given email id from given email id with attachment
def Sendemail():
	global fromaddr
	global toaddrs
	global attachmentFilePath
	global filePermission
	global password
	global attachmentfileName
	global emailsubject
	global emailbody
	
	try:
		for toaddr in range(len(toaddrs)):
			msg = MIMEMultipart()

			msg['From'] = fromaddr
			msg['To'] = toaddrs[toaddr]
			msg['Subject'] = emailsubject

			body = emailbody
				
			msg.attach(MIMEText(body, 'plain'))

			filename = attachmentfileName
			attachment = open(attachmentFilePath, filePermission)
				
			part = MIMEBase('application', 'octet-stream')
			part.set_payload((attachment).read())
			encoders.encode_base64(part)
			part.add_header('Content-Disposition', "attachment; filename= %s" % filename)
				
			msg.attach(part)
				
			server = smtplib.SMTP('smtp.gmail.com', 587)
			server.starttls()
			server.login(fromaddr, password)
			text = msg.as_string()
			server.sendmail(fromaddr, toaddrs[toaddr], text)
			server.quit()	
		print "Email sent with attachment successfully"
		
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)

#print attachmentFilePath
#if os.path.isfile(attachmentFilePath):

if not os.path.exists(attachmentFilePath):
	"Zip file "+attachmentFilePath+" does not exist"
else:
	Sendemail()