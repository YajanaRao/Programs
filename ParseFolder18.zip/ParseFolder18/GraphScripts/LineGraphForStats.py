import xlrd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables
	
def gettingScriptName(scriptName,Folder,ExcelFileName):
	try:
		ExcelFileName = parentpath+"/"+ExcelFileName+'_'+scriptName+'.xlsx'

		# Open the workbook
		book = xlrd.open_workbook(ExcelFileName,"rb")

		# get the list of sheets
		sheet = book.sheets()

		#storing the sheet name in worksheet
		worksheet = book.sheet_by_index(0)

		RowCount = (sheet[0].nrows)
		ColumnCount = (sheet[0].ncols)

		#get number of iteration in output file
		iteration=GraphMethods.GetIterationCount(book)

		#counting no. of users in 
		statrange=GraphMethods.RowIndex(worksheet,RowCount,1,"stats")
		totalstats=statrange[1]-statrange[0]

		# declaration of array for x axis labels
		X=[]

		#preparing array for statistics
		statistics=["Average","minimum","maximum"]

		for us in range (0,iteration):
			X.append("Iteration"+str(us+1))
			
		Actions=GraphMethods.GetRowValue(worksheet,ColumnCount,len(Allvariables.CSVHeadings)+4)
		
		if not os.path.exists(Folder):
			os.makedirs(Folder)
			
		for Stats in range(totalstats):
			Y=[]
			for acts in range(len(Actions)):
				A=[]
				for itr in range (iteration):
					usersrange=GraphMethods.RowIndex(worksheet,RowCount,itr+1,"stats")
					temper=GraphMethods.GetColumnValue(worksheet,usersrange[0]+Stats,usersrange[0]+1+Stats,acts+1)
					A.append(temper[0])
				Y.append(A)
			
			fig = plt.figure(figsize=(20.0, 15.0))
			#title for the graph
			fig.suptitle('LineGraph\nResponse time  v/s Iterations of '+statistics[Stats], fontsize=14, fontweight='bold')
			ax = fig.add_subplot(111)
			fig.subplots_adjust(top=0.85)
			
			#title for X-axis and Y axis
			ax.set_xlabel('Iterations', fontsize=11, fontweight='bold')
			ax.set_ylabel('Response time in millisec', fontsize=11, fontweight='bold')
			ind=np.arange(len(X))
			plt.subplot(111)

			for value in range (len(Actions)):
				plt.plot(Y[value],label=Actions[value])
				
			pngfilename = Folder+'\LineGraphFor'+statistics[Stats]+".png"


			plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
			plt.xticks(ind,X)
			plt.savefig(pngfilename) 
			#plt.show()
			plt.close()
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)