import xlrd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables

def gettingScriptName(scriptName,Folder,ExcelFileName):
	try:
		#calling method and storing all the required data from text file
		ExcelFileName = parentpath+"/"+ExcelFileName+'_'+scriptName+'.xlsx'

		# Open the workbook
		book = xlrd.open_workbook(ExcelFileName,"rb")

		# get the list of sheets
		sheet = book.sheets()

		#storing the sheet name in worksheet
		worksheet = book.sheet_by_index(0)

		ColumnCount = (sheet[0].ncols)
		RowCount = (sheet[0].nrows)

		iteration=GraphMethods.GetIterationCount(book)

		statrange=GraphMethods.RowIndex(worksheet,RowCount,1,"stats")
		totalstats=statrange[1]-statrange[0]

		X=[]
		statistics=["Average","minimum","maximum"]

		for us in range (0,iteration):
			X.append("Iteration"+str(us+1))
			
		Actions=GraphMethods.GetRowValue(worksheet,ColumnCount,len(Allvariables.CSVHeadings)+4)
		
		if not os.path.exists(Folder):
			os.makedirs(Folder)

		for Stats in range(totalstats):
			Y=[]
			n=0
			fig = plt.figure(figsize=(20.0, 15.0))
			fig.suptitle('BarGraph\nResponse time  v/s Iterations of '+statistics[Stats], fontsize=14, fontweight='bold')
			ax = fig.add_subplot(111)
			fig.subplots_adjust(top=0.85)

			ax.set_xlabel('Iterations', fontsize=11, fontweight='bold')
			ax.set_ylabel('Response time in millisec', fontsize=11, fontweight='bold')
			
			for acts in range(len(Actions)):
				A=[]
				for itr in range (iteration):
					usersrange=GraphMethods.RowIndex(worksheet,RowCount,itr+1,"stats")
					temper=GraphMethods.GetColumnValue(worksheet,usersrange[0]+Stats,usersrange[0]+1+Stats,acts+1)
					A.append(temper[0])
				Y.append(A)
				
			ind=np.arange(len(X))
			
			for i in range(len(Actions)):
				plt.bar(ind+n,Y[i],width=0.15,label=Actions[i], align="center")
				n=n+0.15
				
			pngfilename = Folder+'\BarChartFor'+statistics[Stats]+".png"

			ax.legend()
			plt.xticks(ind,X)
			plt.savefig(pngfilename) 
			#plt.show()
			plt.close()
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)