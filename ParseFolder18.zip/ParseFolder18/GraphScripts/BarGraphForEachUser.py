import xlrd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables

def gettingScriptName(ScriptName,Folder,ExcelFileName):
	try:
		ExcelFileName = parentpath+"/"+ExcelFileName+'_'+ScriptName+'.xlsx'

		# Open the workbook
		book = xlrd.open_workbook(ExcelFileName,"rb")

		# get the list of sheets
		sheet = book.sheets()

		#storing the sheet name in worksheet
		worksheet = book.sheet_by_index(0)

		RowCount = (sheet[0].nrows)
		ColumnCount = (sheet[0].ncols)
	
		iteration=GraphMethods.GetIterationCount(book)

		userrange=GraphMethods.RowIndex(worksheet,RowCount,1,"")
		totalusers=userrange[1]-userrange[0]
		X=[]

		#looping for x axis labels
		for us in range (0,iteration):
			X.append("Iteration"+str(us+1))

		Actions=GraphMethods.GetRowValue(worksheet,ColumnCount,len(Allvariables.CSVHeadings)+4)
		
		if not os.path.exists(Folder):
			os.makedirs(Folder)

		for userloop in range(totalusers):
			Y=[]
			n=0
			fig = plt.figure(figsize=(20.0, 15.0))
			fig.suptitle('BarGraph\nResponse Time v/s Iterations of User'+str(userloop+1), fontsize=14, fontweight='bold')
			ax = fig.add_subplot(111)
			fig.subplots_adjust(top=0.85)

			ax.set_xlabel('Iterations', fontsize=11, fontweight='bold')
			ax.set_ylabel('Response time in millisec', fontsize=11, fontweight='bold')
			
			for acts in range(len(Actions)):
				A=[]
				for itr in range (iteration):
					datarange=GraphMethods.RowIndex(worksheet,RowCount,itr+1,"")
					temper=GraphMethods.GetColumnValue(worksheet,datarange[0]+userloop,datarange[0]+1+userloop,acts+1)
					A.append(temper[0])
				Y.append(A)
			#print Y
			#print "\n"
			ind=np.arange(len(X))

			for i in range(len(Actions)):
				plt.bar(ind+n,Y[i],width=0.15,label=Actions[i], align="center")
				n=n+0.15
				
			pngfilename = Folder+'\BarGraphForUser'+str(userloop+1)+".png"
			
			ax.legend()
			plt.xticks(ind,X)
			plt.savefig(pngfilename) 
			#plt.show()
			plt.close()
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)