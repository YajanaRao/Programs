import xlrd
from xlrd import open_workbook
import matplotlib.pyplot as plt
import numpy as np
import matplotlib.pyplot as plt
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables

def gettingScriptName(scriptName,Folder,ExcelFileName):
	try:
		ExcelFileName = parentpath+"/"+ExcelFileName+'_'+scriptName+'.xlsx'

		# Open the workbook
		book = xlrd.open_workbook(ExcelFileName,"rb")

		# get the list of sheets
		sheet = book.sheets()

		# storing number of rows and cols in sheet
		RowCount = (sheet[0].nrows)
		ColumnCount = (sheet[0].ncols)

		#storing the sheet name in worksheet
		worksheet = book.sheet_by_index(0)

		iteration=GraphMethods.GetIterationCount(book)
		
		if not os.path.exists(Folder):
			os.makedirs(Folder)
			
		for itr in range(iteration):
			rowin = GraphMethods.RowIndex(worksheet,RowCount,itr+1,"colhead")
			actionname = GraphMethods.GetRowValue(worksheet,ColumnCount,rowin)
			#print actionname
			for action in range(len(actionname)):
				labels = []
				rowr = GraphMethods.RowIndex(worksheet,RowCount,itr+1,"")
				users = GraphMethods.GetColumnValue(worksheet,rowr[0],rowr[1],0)
				data = GraphMethods.GetColumnValue(worksheet,rowr[0],rowr[1],action+1)
				for user in range(len(users)):
					dump = ''+users[user]+'('+str(data[user])+')'
					labels.append(dump)
				#print data
				
				title = plt.title('PieGraph For All Users in '+actionname[action]+' (Iteration'+str(itr+1)+')')
				title.set_ha("left")
				plt.gca().axis("equal")
				pie = plt.pie(data, startangle=0)
				
				pngfilename = Folder+'\PieChartFor'+actionname[action]+'Iteration'+str(itr+1)+'.png'
				
				plt.legend(pie[0],labels, bbox_to_anchor=(1,0.5), loc="right", fontsize=10, 
							bbox_transform=plt.gcf().transFigure)
				plt.subplots_adjust(left=0.0, bottom=0.1, right=0.45)
				plt.savefig(pngfilename)
				#plt.show()
				plt.close()
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)