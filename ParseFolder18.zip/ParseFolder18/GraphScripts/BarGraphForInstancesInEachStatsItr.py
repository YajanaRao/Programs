import xlrd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables

def gettingScriptName(scriptName,IPArray,Iteration,Users,Folder,browser,cache):
	#excel file name with path
	ExcelFileName = parentpath+'/'+Allvariables.CombinedExcelFileName+'_'+scriptName+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention

	# Open the workbook
	book = xlrd.open_workbook(ExcelFileName,"rb")

	# get the list of sheets
	sheet = book.sheets()

	#storing the sheet name in worksheet
	worksheet = book.sheet_by_index(0)

	RowCount = (sheet[0].nrows)
	ColumnCount = (sheet[0].ncols)
	
	val = GraphMethods.findIPAddress(worksheet,RowCount,IPArray[0])
	Actions = GraphMethods.GetRowValue(worksheet,ColumnCount,val[0]+1)
		
	Stats = ["Average","Minimum","Maximum"]
	
	if not os.path.exists(Folder):
		os.makedirs(Folder)
		
	for itr in range(Iteration):
		for stat in range(len(Stats)):
			n=0
			X=IPArray
			Y=[]
			for action in range(len(Actions)):
				I = []
				for instance in range(len(IPArray)):
					instancedatarange = GraphMethods.findIPAddress(worksheet,RowCount,IPArray[instance])
					datarange=GraphMethods.GetRowIndInCombinedSheet(worksheet,instancedatarange[0],instancedatarange[1],itr+1,"stats")
					temp = GraphMethods.GetColumnValue(worksheet,datarange[0]+stat,datarange[0]+1+stat,action+1)
					I.append(temp[0])
				Y.append(I)
			#print Y
			#print "\n"
				
			fig = plt.figure(figsize=(20.0, 15.0))
			fig.suptitle('BarGraph\nResponse Time v/s Instances of all actions in '+Stats[stat]+'(Iteration'+str(itr+1)+')', fontsize=14, fontweight='bold')
			ax = fig.add_subplot(111)
			fig.subplots_adjust(top=0.85)

			ax.set_xlabel('Instances', fontsize=11, fontweight='bold')
			ax.set_ylabel('Response time in millisec', fontsize=11, fontweight='bold')
			
			ind=np.arange(len(X))
			
			for i in range(len(Actions)):
				plt.bar(ind+n,Y[i],width=0.15,label=Actions[i], align="center")
				n=n+0.15
			
			ax.legend()
			plt.xticks(ind,X)
			pngfilename = Folder+'\BGForInstances'+Stats[stat]+'Itr'+str(itr+1)+".png"
			plt.savefig(pngfilename) 
			#plt.show()
			plt.close()