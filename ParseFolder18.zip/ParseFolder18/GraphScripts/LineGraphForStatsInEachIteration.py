import xlrd
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os.path
import sys
import GraphMethods

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables

def gettingScriptName(scriptName,Folder,ExcelFileName):	
	try:
		ExcelFileName = parentpath+"/"+ExcelFileName+'_'+scriptName+'.xlsx'
		# Open the workbook
		book = xlrd.open_workbook(ExcelFileName,"rb")

		# get the list of sheets
		sheet = book.sheets()

		#storing the sheet name in worksheet
		worksheet = book.sheet_by_index(0)
		
		RowCount = (sheet[0].nrows)
		ColumnCount = (sheet[0].ncols)
		
		iteration=GraphMethods.GetIterationCount(book)
		Actions=GraphMethods.GetRowValue(worksheet,ColumnCount,len(Allvariables.CSVHeadings)+4)
		
		if not os.path.exists(Folder):
			os.makedirs(Folder)

		for iter in range (0,iteration):
			Y=[]
			statsrange=GraphMethods.RowIndex(worksheet,RowCount,iter+1,"stats")
			X=GraphMethods.GetColumnValue(worksheet,statsrange[0],statsrange[1],0)
			
			for var in range (len(Actions)):
				Y.append(GraphMethods.GetColumnValue(worksheet,statsrange[0],statsrange[1],var+1))
			#print Y
			
			fig = plt.figure(figsize=(20.0, 15.0))
			fig.suptitle('Response time  v/s Statistics(Iteration '+str(iter+1)+')', fontsize=14, fontweight='bold')
			ax = fig.add_subplot(111)
			fig.subplots_adjust(top=0.85)

			ax.set_xlabel('Statistics', fontsize=11, fontweight='bold')
			ax.set_ylabel('Response time in millisec', fontsize=11, fontweight='bold')

			ind=np.arange(len(X))
			plt.subplot(111)
			
			for value in range (len(Actions)):
				plt.plot(Y[value],label=Actions[value])
				#print value
				
			pngfilename = Folder+'\LineGraphForStatsInIteration'+str(iter+1)+'.png'

			plt.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0.)
			plt.xticks(ind,X)
			plt.savefig(pngfilename) 
			#plt.show()
			plt.close()
	except Exception as e:
		print "Exception is: "+str(e)
		sys.exit(0)