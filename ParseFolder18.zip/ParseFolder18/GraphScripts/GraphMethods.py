import sys
import xlrd
import numpy as np
import os

currentpath = os.path.dirname(os.path.realpath(__file__))
parentpath = os.path.abspath(os.path.join(currentpath, os.pardir))
sys.path.insert(0,parentpath)
import Allvariables
	
#this method return the count of iteration
def GetIterationCount(book):
	count=0
	for sheet in book.sheets():
		for rowidx in range(sheet.nrows):
			row = sheet.row(rowidx)
			for colidx, cell in enumerate(row):
				if cell.value == "Iteration"+str(count+1) :
					count=count+1
	return count

#this method takes number of rows in a sheet,iteration number and string and returns the row range	
def RowIndex(worksheet,RowCount,itrno,string):
	iterations = "Iteration"+str(itrno)
	stats,users=[],[]
	minindex = ''
	maxindex = ''
	for rowidx in range(RowCount):
		dump = worksheet.cell_value(rowidx, 0)
		if dump == iterations:
			minindex = rowidx
			users.append(minindex+2)
			break
	for maxidx in range(minindex,RowCount):
		temp = worksheet.cell_value(maxidx, 0)
		if temp == '':
			maxindex = maxidx
			stats.append(maxindex+1)
			stats.append(maxindex+4)
			users.append(maxindex)
			break
	if string == 'max':
		return (maxindex+3)
	elif string == 'min':
		return (maxindex+2)
	elif string == 'avg':
		return (maxindex+1)
	elif string == 'colhead':
		return (minindex+1)
	elif string == 'stats':
		return stats
	else:
		return users
		
#this method takes instance IP address and number of rows in a sheet and returns the row range of that instance data	
def findIPAddress(worksheet,RowCount,IP):
	array = []
	for i in range(RowCount):
		val = worksheet.cell_value(i,1)
		if val==IP:
			val2 = i
	for j in range(val2,RowCount):
		val = worksheet.cell_value(j,0)
		if val == "":
			val3 = j+1
			break
	for k in range(val2,RowCount):
		val = worksheet.cell_value(k,0)
		if val == Allvariables.endSymbol:
			val4 = k-1
			break
	array.append(val3)
	array.append(val4)
	return array
		
#this method takes row range of each instances, iteration number, string and returns the range of iteration data	
def GetRowIndInCombinedSheet(worksheet,rowMinRange,rowMaxrange,itrno,string):
	iterations = "Iteration"+str(itrno)
	stats,users=[],[]
	for rowidx in range(rowMinRange,rowMaxrange):
		dump = worksheet.cell_value(rowidx, 0)
		if dump == iterations:
			minindex = rowidx
			users.append(minindex+2)
			break
	for maxidx in range(minindex,rowMaxrange):
		temp = worksheet.cell_value(maxidx, 0)
		if temp == '':
			maxindex = maxidx
			stats.append(maxindex+1)
			stats.append(maxindex+4)
			users.append(maxindex)
			break
	if string == 'max':
		return (maxindex+3)
	elif string == 'min':
		return (maxindex+2)
	elif string == 'avg':
		return (maxindex+1)
	elif string == 'colhead':
		return (minindex+1)
	elif string == 'stats':
		return stats
	else:
		return users
		
#this method takes number of columns in a sheet, row number and returns the row value	
def GetRowValue(worksheet,ColumnCount,rowvalue):
	temp = []
	for i in range(1,(ColumnCount-3)):
		val = worksheet.cell_value(rowvalue,i)
		temp.append(val)
	return temp

#this method takes row range(min,max) and column number and returns the data
def GetColumnValue(worksheet,rowmin,rowmax,colnum):
	temp = []
	for i in range(rowmin,rowmax):
		val = worksheet.cell_value(i,colnum)
		temp.append(val)
	return temp