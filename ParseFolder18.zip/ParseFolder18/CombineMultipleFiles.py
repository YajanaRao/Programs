import pandas as pd
import unicodecsv
import Allvariables
import Allmethods
import glob

def gettingIPAddress(scriptName,ExcelFileName,CSVFileName,CsvFolder,browser,cache):
	#storing excel file name with full path
	ExcelFileName = ExcelFileName+'_'+scriptName+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention
	ExcelFileFullPath = Allvariables.currentpath+"/"+ExcelFileName
	
	#storing the csv file name with full path
	CSVFileFullPath = Allvariables.currentpath+''+CsvFolder+"/"+CSVFileName+'_'+scriptName+'.csv'
	
	#calling method to convert excel to csv file
	Allmethods.xls2csv(ExcelFileFullPath,CSVFileFullPath)
	print "Converted to csv format"	

def combineMultipleExcelToCSV(ExcelFileName,ScriptName,IPArray,CSVFolderName,browser,cache):
	# declaring empty array for storing all excel filenames
	excel_names = []
	
	#looping for storing all excel file names
	for IP in range(len(IPArray)):
		temp = ExcelFileName+'_'+ScriptName+'_'+IPArray[IP]+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention
		excel_names.append(temp)
		
	# read them in
	excels = [pd.ExcelFile(name) for name in excel_names]

	# turn them into dataframes
	frames = [x.parse(x.sheet_names[0], header=None,index_col=None) for x in excels]
	
	#removing repeated headings
	'''if ApplicationName == Allvariables.applicationName:
		# i.e. remove the header row -- assumes it's the first
		frames[1:] = [df[1:] for df in frames[1:]]'''
		
	# concatenate them..
	combined = pd.concat(frames)

	# write it out in a combined excel file and CSV file
	combined.to_excel(Allvariables.CombinedExcelFileName+'_'+ScriptName+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention, header=False, index=False)
	combined.to_csv(CSVFolderName+"/"+Allvariables.CombinedCSVFileName+'_'+ScriptName+'_'+browser+'_Cache'+str(cache)+'.csv', header=False, index=False)
	print "Combined Multiple excel files into one successfully"
	
	
def combineMultipleExcelToCSV(ExcelFileName,ScriptName,IPArray,ExcelFolderName,browser,cache,ApplicationName):
	# declaring empty array for storing all excel filenames
	excel_names = []
	
	#looping for storing all excel file names
	for IP in range(len(IPArray)):
		temp = ExcelFileName+'_'+ScriptName+'_'+IPArray[IP]+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention
		excel_names.append(temp)

	def combine_excel_to_dfs(excel_names, sheetname):
		sheet_frames = [pd.read_excel(x, sheet_name=sheetname) for x in excel_names]
		combined_df = pd.concat(sheet_frames).reset_index(drop=True)

		return combined_df

	df_first = combine_excel_to_dfs(excel_names, 1)
	df_second = combine_excel_to_dfs(excel_names, 0)

	# Create a Pandas Excel writer using XlsxWriter as the engine.
	writer = pd.ExcelWriter(ExcelFolderName+'/'+ScriptName+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention, engine='xlsxwriter')

	# Write each dataframe to a different worksheet.
	df_first.to_excel(writer, sheet_name='Headings',index=False)
	df_second.to_excel(writer, sheet_name=ScriptName,index=False)
	
	# Get the xlsxwriter workbook and worksheet objects.
	workbook  = writer.book
	worksheet = writer.sheets['Headings']
	worksheet2 = writer.sheets[ScriptName]

	# Set the column width and format.
	worksheet.set_column('A:P', 25)
	worksheet2.set_column('A:P', 25)

	# Close the Pandas Excel writer and output the Excel file.
	writer.save()
	
def combineMultipleExcelToCSV(ExcelFileName,ScriptName,IPArray,ExcelFolderName,browser,cache,ApplicationName):
	# declaring empty array for storing all excel filenames
	excel_names = []
	
	#looping for storing all excel file names
	for IP in range(len(IPArray)):
		temp = ExcelFileName+'_'+ScriptName+'_'+IPArray[IP]+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention
		excel_names.append(temp)

	def combine_excel_to_dfs(excel_names, sheetname):
		sheet_frames = [pd.read_excel(x, sheet_name=sheetname) for x in excel_names]
		combined_df = pd.concat(sheet_frames).reset_index(drop=True)

		return combined_df

	df_first = combine_excel_to_dfs(excel_names, 1)
	df_second = combine_excel_to_dfs(excel_names, 0)

	# Create a Pandas Excel writer using XlsxWriter as the engine.
	writer = pd.ExcelWriter(ExcelFolderName+'/'+ScriptName+'_'+browser+'_Cache'+str(cache)+''+Allvariables.ExcelFileExtention, engine='xlsxwriter')

	# Write each dataframe to a different worksheet.
	df_first.to_excel(writer, sheet_name='Headings',index=False)
	df_second.to_excel(writer, sheet_name=ScriptName,index=False)
	
	# Get the xlsxwriter workbook and worksheet objects.
	workbook  = writer.book
	worksheet = writer.sheets['Headings']
	worksheet2 = writer.sheets[ScriptName]

	# Set the column width and format.
	worksheet.set_column('A:P', 25)
	worksheet2.set_column('A:P', 25)

	# Close the Pandas Excel writer and output the Excel file.
	writer.save()
	
def combineMultipleCombinedExcelFiles(ExcelFolderName):
	# declaring empty array for storing all excel filenames
	excel_names = glob.glob(ExcelFolderName+"/*.xlsx")

	def combine_excel_to_dfs(excel_names, sheetname):
		sheet_frames = [pd.read_excel(x, sheet_name=sheetname) for x in excel_names]
		combined_df = pd.concat(sheet_frames).reset_index(drop=True)
		return combined_df

	df_first = combine_excel_to_dfs(excel_names, 0)
	df_second = combine_excel_to_dfs(excel_names, 1)

	# Create a Pandas Excel writer using XlsxWriter as the engine.
	writer = pd.ExcelWriter(ExcelFolderName+'/'+Allvariables.CombinedAllExcelFileName+''+Allvariables.ExcelFileExtention, engine='xlsxwriter')

	# Write each dataframe to a different worksheet.
	df_first.to_excel(writer, sheet_name='Headings',index=False)
	df_second.to_excel(writer, sheet_name='ResponseTime',index=False)
	
	# Get the xlsxwriter workbook and worksheet objects.
	workbook  = writer.book
	worksheet = writer.sheets['Headings']
	worksheet2 = writer.sheets['ResponseTime']

	# Set the column width and format.
	worksheet.set_column('A:Q', 25)
	worksheet2.set_column('A:Q', 25)

	# Close the Pandas Excel writer and output the Excel file.
	writer.save()