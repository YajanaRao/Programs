
# this is to read ip address from report folder to ipaddress.txt
cd C:\\AWS\\Distributed-setup-3\\Reports
ls > ipaddress.txt
cd C:\\Users\\Yajana\\Desktop\\ParseFolder18

# calling ParseAndGenerateGraphs.py for executing parsing script with generating graphs
python ParseAndGenerateGraphs.py
#python ZipAFolder.py
#python SendEmail.py

#del "*.xlsx"
#del "*.pyc"
#del ipaddress.txt

#cd GraphScripts
#del "*.pyc"
#cd..