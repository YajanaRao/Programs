Note: This SetUp is for Windows10

-- INITIAL SETUP FOR PYTHON --

1. Download and install Python 2.7.14
2. Commands to Install python libraries which is required to run the scripts is here below.

**** Commands ****
1. python -m pip install pandas
2. python -m pip install XlsxWriter
3. python -m pip install unicodecsv
4. python -m pip install urllib3
5. python -m pip install xlrd
6. python -m pip install xlwt
7. python -m pip install xlutils
8. python -m pip install matplotlib
9. python -m pip install openpyxl
-------------------------------

-- SETUP FOR RUNNING SCRIPT --

ScriptInputFile.txt
//Give YAML input file full path along with file name(Note: without extention)
YAMLFilePath: your yaml file full path

UserInputFile.txt
//Give in Give the jmeter output file path and initial name(Note: without extention)
JmeterOutputFilePath: your Timestamp file path

parse.bat
//Give Timestamp file path(Note: without filename and extension)
