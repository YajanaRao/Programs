import sys
import os
from sys import exit
import Allvariables
import Allmethods
import ParseTimestampFiles
import Combiningsheets
import CombineMultipleFiles

try:
	#calling ReadTextfile to read all the IP addresses in which the scripts are ran
	IPArray = Allmethods.ReadTextFile()
except Exception as e:
	print "Exception is: "+str(e)
	sys.exit(0)
	
#calling ReadPath method to read all values in script input file and storing in a allScriptInputs array
allScriptInputs = Allmethods.ReadPath(Allvariables.scriptinputfile,Allvariables.scriptInputFileHeadings)
#print allScriptInputs
#print len(allScriptInputs)
#print allScriptInputs[23]
	
#calling ReadPath method to read required values from user input file
userInputs = Allmethods.ReadPath(Allvariables.inputfilename,Allvariables.userInputFileHeadings)
#print userInputs

try:
	#calling readYaml file to read script name from input file
	ScriptName = Allmethods.readYaml(userInputs[1]+''+Allvariables.executionInputFileExtention,"scripts")
		
	#calling readYaml method in another file to read number of iteration,users,ramp-up
	execution = Allmethods.readYaml(userInputs[1]+''+Allvariables.executionInputFileExtention,"execution")
	
	#calling readYaml method in another file to read number of browsers
	OperatingSystem = Allmethods.readYaml(userInputs[1]+''+Allvariables.executionInputFileExtention,"operatingsystem")

	#calling readYaml method in another file to read cache enabled or not
	cache_flag = Allmethods.readYaml(userInputs[1]+''+Allvariables.executionInputFileExtention,"cache")
	
	#calling readYaml method in another file to read number of browsers
	browsers = Allmethods.readYaml(userInputs[1]+''+Allvariables.executionInputFileExtention,"browsers")
		
	#separating from list and storing the values of number of iteration,users,ramp-up
	for item in range(len(execution)):
		for key, value in execution[item].iteritems():
			execution[item]=value
except Exception as e:
	print "Exception is: "+str(e)
	sys.exit(0)

if userInputs[2] != Allvariables.applicationName:
	#storing the name and path of the folder where all CSV files should be stored
	CSVFolderName = Allvariables.currentpath+''+allScriptInputs[0]

	#storing the name and path of folder containing all scripts related to graphs
	GraphScriptFilePath = Allvariables.currentpath+''+allScriptInputs[8]

	#storing the name and path of the folder where all graphs should be stored
	GraphFolderName = Allvariables.currentpath+''+allScriptInputs[1]
		
	#storing the name and path of the folder where all graphs related to different instances should be stored
	CombinedGraphFolder = GraphFolderName+''+allScriptInputs[9]
		
	#including the graph folder to execute all the graph script in that particular folder
	sys.path.insert(0,GraphScriptFilePath)

	#importing scripts related to plot graphs for each instance
	import BarGraphForActionsInEachUser
	import BarGraphForEachUser
	import BarGraphForStats
	import BarGraphForStatsInEachIteration
	import BarGraphForUserInEachIteration
	import Piechart_action_iteration
	import LineGraphForActionsInEachUser
	import LineGraphForEachUser
	import LineGraphForStats
	import LineGraphForStatsInEachIteration
	import LineGraphForUserInEachIteration
	#importing scripts related to plot graphs for different instances
	import BarGraphForInstancesInEachItrUser
	import LineGraphForInstancesInEachItrUser
	import BarGraphForInstancesInEachActionItr
	import LineGraphForInstancesInEachActionItr
	import BarGraphForInstancesInEachStatsItr
	import LineGraphForInstancesInEachStatsItr
	import BarGraphForInstancesInEachActionStats
	import LineGraphForInstancesInEachActionStats
	import BarGraphForInstancesTotalTimeInEachUserItr
	import LineGraphForInstancesTotalTimeInEachUserItr
	import BarGraphForUsersInInstancesEachActionItr
	import LineGraphForUsersInInstancesEachActionItr
	import BarGraphForActionsInInstancesEachUserItr
	import LineGraphForActionsInInstancesEachUserItr
	
	#this is to rename the existing folder with current time
	if os.path.exists(CSVFolderName):
		#renaming directory
		os.rename(CSVFolderName,Allvariables.ChangeCSVFolderName)
		os.rename(GraphFolderName,Allvariables.ChangeGraphFoldername)
		os.rename(Allvariables.ScreenshotFolderName2,Allvariables.ChangedScreenshotFolderName)

	#creating folder structure
	if not os.path.exists(CSVFolderName):
		os.makedirs(CSVFolderName)
	if not os.path.exists(GraphFolderName):
		os.makedirs(GraphFolderName)
	if not os.path.exists(Allvariables.ScreenshotFolderName):
		os.makedirs(Allvariables.ScreenshotFolderName)	
else:
	#Excel file folder name
	ExcelFolderName = Allvariables.currentpath+''+allScriptInputs[23]
	print ExcelFolderName
	
	if os.path.exists(ExcelFolderName):
		os.rename(ExcelFolderName,Allvariables.ChangeExcelFolderName)
		
	#creating folder structure
	if not os.path.exists(ExcelFolderName):
		os.makedirs(ExcelFolderName)

#this is to replace extension from script name	
for item in range(len(ScriptName)):
	ScriptName[item] = ScriptName[item].replace(Allvariables.ScriptExtention,"")

#declaring an array for storing unique IP address which has Timestamp files in required directory
IPOfExistedTimestampFiles = []

#calling all files which are required for parsing and generating graphs
for browser in range(len(browsers)):
	for cache in range(len(cache_flag)):
		for script in range(len(ScriptName)):
			#declaring two arrays as empty
			TimestampFileVarArray,IPAddresses = [],[]
			for IP in range(len(IPArray)):
				TimestampFileVariable = ScriptName[script]+'_'+IPArray[IP]
					
				#calling file to parse the Timestamp file and storing in excel file
				csvHeadings = ParseTimestampFiles.gettingIPAddress(TimestampFileVariable,userInputs[0],allScriptInputs[16],cache_flag[cache],userInputs[2])
					
				#printing the status if the timestamp file is missing for particular IP address
				if "does not exist" in csvHeadings:
					print csvHeadings+"\n"
				else:
					IPAddresses.append(IPArray[IP])
					TimestampFileVarArray.append(TimestampFileVariable)
					
					#calling file to combine all sheets into one excel file with headings for csv file
					Combiningsheets.gettingIPAddress(TimestampFileVariable,csvHeadings,allScriptInputs[16],allScriptInputs[17],browsers[browser],cache_flag[cache],userInputs[2])
					
					if userInputs[2] != Allvariables.applicationName:
						#calling method in file to convert xlsx file to csv for each script run in each instance
						CombineMultipleFiles.gettingIPAddress(TimestampFileVariable,allScriptInputs[17],allScriptInputs[20],allScriptInputs[0],browsers[browser],cache_flag[cache])
						
						#storing the path and name for the graph folder for each IP and each script
						GraphsFolder = GraphFolderName+'\Graphs_'+TimestampFileVariable
							
						#creating folder if not for storing all graphs related to particular IP, particular script
						if not os.path.exists(GraphsFolder):
							os.makedirs(GraphsFolder)
								
						#calling methods in different file to plot graphs according to each instance and each script
						
						ExcelFileVariable = TimestampFileVariable+'_'+browsers[browser]+'_Cache'+str(cache_flag[cache])
						#Bar graph for response time v/s actions with all users in each iteration
						BarGraphForActionsInEachUser.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[4],allScriptInputs[17])
						#Bar graph for response time v/s iteration with all actions in each user
						BarGraphForEachUser.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[2],allScriptInputs[17])
						#Bar graph for response time v/s iteration with all actions in each statistics
						BarGraphForStats.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[7],allScriptInputs[17])
						#Bar graph for response time v/s statistics with all actions in each iteration
						BarGraphForStatsInEachIteration.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[6],allScriptInputs[17])
						#Bar graph for response time v/s users with all actions in each iteration
						BarGraphForUserInEachIteration.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[3],allScriptInputs[17])
						#Pie chart for all users in each action in each iteration
						Piechart_action_iteration.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[5],allScriptInputs[17])
						#Line graph for response time v/s actions with all users in each iteration
						LineGraphForActionsInEachUser.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[4],allScriptInputs[17])	
						#Line graph for response time v/s iteration with all actions in each user
						LineGraphForEachUser.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[2],allScriptInputs[17])	
						#Line graph for response time v/s iteration with all actions in each statistics
						LineGraphForStats.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[7],allScriptInputs[17])
						#Line graph for response time v/s statistics with all actions in each iteration
						LineGraphForStatsInEachIteration.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[6],allScriptInputs[17])	
						#Line graph for response time v/s users with all actions in each iteration
						LineGraphForUserInEachIteration.gettingScriptName(ExcelFileVariable,GraphsFolder+''+allScriptInputs[3],allScriptInputs[17])
						print "Graphs generated successfully"
						print "\n"
			IPOfExistedTimestampFiles.append(IPAddresses)
			
			if userInputs[2] != Allvariables.applicationName:
				#calling file to combine multiple excel files into one for all IP addresses for each script
				CombineMultipleFiles.combineMultipleExcelToCSV(allScriptInputs[17],ScriptName[script],IPAddresses,CSVFolderName,browsers[browser],cache_flag[cache])
			else:
				#calling file to combine multiple excel files into one for all IP addresses for each script
				CombineMultipleFiles.combineMultipleExcelToCSV(allScriptInputs[17],ScriptName[script],IPAddresses,ExcelFolderName,browsers[browser],cache_flag[cache],userInputs[2])
if userInputs[2] == Allvariables.applicationName:
	CombineMultipleFiles.combineMultipleCombinedExcelFiles(ExcelFolderName)

#checking the application name and executing if it is not mammoth application
if userInputs[2] != Allvariables.applicationName:	
	for browser in range(len(browsers)):
		for cache in range(len(cache_flag)):
			for item in range(len(ScriptName)):
				#assigning script name to the folder name for graphs for instance
				CombinedGraphFolder2 = CombinedGraphFolder+'_'+ScriptName[item]+'_'+browsers[browser]+'_Cache'+str(cache_flag[cache])
					
				#creating a folder if not present with the name of script for graphs of instances
				if not os.path.exists(CombinedGraphFolder2):
					os.makedirs(CombinedGraphFolder2)
					
				#Calling methods in different file to plot graphs according to number of instances
				
				#Line graph for response time v/s instances with all actions in each user in each iteration
				LineGraphForInstancesInEachItrUser.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[10],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s instances with all users in each action in each iteration
				BarGraphForInstancesInEachActionItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[11],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s instances with all users in each action in each iteration
				LineGraphForInstancesInEachActionItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[11],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s instances with all statistics in each action in each iteration
				BarGraphForInstancesInEachActionStats.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[12],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s instances with all statistics in each action in each iteration
				LineGraphForInstancesInEachActionStats.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[12],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s instances with all actions in each stats in each iteration
				BarGraphForInstancesInEachStatsItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[13],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s instances with all actions in each stats in each iteration
				LineGraphForInstancesInEachStatsItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[13],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s instances with all users in total time of each iteration
				BarGraphForInstancesTotalTimeInEachUserItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[14],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s instances with all users in total time of each iteration
				LineGraphForInstancesTotalTimeInEachUserItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[14],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s users with all instances in each action in each iteration
				BarGraphForUsersInInstancesEachActionItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[21],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s users with all instances in each action in each iteration
				LineGraphForUsersInInstancesEachActionItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[21],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s actions with all instances in each user in each iteration
				BarGraphForActionsInInstancesEachUserItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[22],browsers[browser],cache_flag[cache])
				#Line graph for response time v/s actions with all instances in each user in each iteration
				LineGraphForActionsInInstancesEachUserItr.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[22],browsers[browser],cache_flag[cache])
				#Bar graph for response time v/s instances with all actions in each user in each iteration
				BarGraphForInstancesInEachItrUser.gettingScriptName(ScriptName[item],IPOfExistedTimestampFiles[item],execution[0],execution[1],CombinedGraphFolder2+''+allScriptInputs[10],browsers[browser],cache_flag[cache])
				print "Graphs for all instances in "+ScriptName[item]+" generated successfully"